package messages;

public class Sample extends Inform {

	private static final long serialVersionUID = 1L;

	public Sample(double value) {
		super(value);
	}

}
