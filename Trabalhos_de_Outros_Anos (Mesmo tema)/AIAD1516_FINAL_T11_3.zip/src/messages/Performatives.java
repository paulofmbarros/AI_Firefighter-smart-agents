package messages;

public final class Performatives {

	public static final int INFORM = 0;
	public static final int FIRM_ADHERENCE = 1;
	public static final int ACK_ADHERENCE = 2;
	public static final int BREAK = 3;
	public static final int WITHDRAW = 4;

}
