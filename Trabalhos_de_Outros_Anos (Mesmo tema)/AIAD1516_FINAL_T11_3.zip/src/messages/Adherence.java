package messages;

public class Adherence extends Inform {

	private static final long serialVersionUID = 1L;

	public Adherence(double value) {
		super(value);
	}

}
