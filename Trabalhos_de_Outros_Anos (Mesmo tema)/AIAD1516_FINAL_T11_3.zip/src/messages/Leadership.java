package messages;

public class Leadership extends Inform {

	private static final long serialVersionUID = 1L;

	public Leadership(double value) {
		super(value);
	}

}
