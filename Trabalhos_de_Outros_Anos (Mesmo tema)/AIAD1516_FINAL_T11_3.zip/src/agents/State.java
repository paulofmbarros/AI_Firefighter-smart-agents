package agents;

public enum State {
	ON, SLEEP, OFF
}
